import React from 'react';

const MealDecPage = (itemID) => {
    return (
        <div>
            <h1>{itemID}</h1>
        </div>
    );
};

export default MealDecPage();