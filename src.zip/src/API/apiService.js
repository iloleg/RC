import axios from "axios";

export default class ApiService {
    static async getAll(limit = 5, offset = 1) {
        try {
            const response = await axios.get(`https://api.spoonacular.com/recipes/complexSearch?apiKey=50936cfd0256444abc7d267b3717f0e3&number=${limit}&offset=${offset}`)



            return response

        } catch (e) {
            console.log(e)
        }

    }
}