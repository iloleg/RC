import React from 'react';
import PostMeal from "./PostMeal";


const MealList = ({props, title1}) => {


    if (!props.length) {
        console.log(props)
        return (
            <h1 style={{textAlign: 'center'}}> Not find any meals </h1>
        )
    }


    return (
        <div>
            <h1 style={{textAlign: 'center'}}>
                {title1}
            </h1>
            {props.map(meal =>
                <PostMeal meal={meal} key={meal.id}/>
            )}
        </div>

    );
};

export default MealList;