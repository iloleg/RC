import React from 'react';
import './componets.css';
import MealDecPage from "../pages/MealDecPage";

const PostMeal = (props) => {
    return (

        <div className="meal">
            <div className="meal__content">

                    <h2>{props.meal.title} </h2>
                    <div>

                        <img className="meal_list_image" src={props.meal.image} alt={props.meal.title}/>
                      
                    </div>

            </div>

        </div>
    );
};

export default PostMeal;